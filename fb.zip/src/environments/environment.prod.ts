export const environment = {
  production: true,
  apiUrl: '',
  baseUrl: 'https://www.fbcoach.com:4000/',
  //baseUrl: 'http://192.168.29.221:4001',
  firebaseConfig: {
    apiKey: "AIzaSyAeYMD4HLgcRUz4eIXTFNgu9ADJMkz5P_g",
    authDomain: "finding-balance-7920f.firebaseapp.com",
    projectId: "finding-balance-7920f",
    storageBucket: "finding-balance-7920f.appspot.com",
    messagingSenderId: "1015006060095",
    appId: "1:1015006060095:web:69ec8a8513fb389dcd628a",
    measurementId: "G-TYC5XTBX16",
    vapidKey: "BL9aycmHcxZ2Ja2JD2ybe27Toc0B9p83seAtfNpGmGWjivIj0SkMAroX2VvzVDcI_N1eY_Gotjuv7J6dvzAhK2M"
  }
}